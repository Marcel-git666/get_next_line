# get_next_line
A function that returns a line read from a file descriptor
